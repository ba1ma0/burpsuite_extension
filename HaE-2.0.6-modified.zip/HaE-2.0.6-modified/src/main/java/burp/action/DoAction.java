package burp.action;

import java.util.Map;
import burp.Config;
import java.util.ArrayList;
import java.util.List;

/*
 * @author EvilChen
 */

public class DoAction {
    public String extractString(Map<String, Map<String, Object>> obj) {
        String[] result = {""};
        obj.keySet().forEach(i->{
            Map<String, Object> tmpMap = obj.get(i);
            String data = tmpMap.get("data").toString();
            String tmpStr = String.format(Config.outputTplString, i, data).intern();
            result[0] += tmpStr;
        });
        return result[0];
    }

    public List<String> highlightList(Map<String, Map<String, Object>> obj) {
        List<String> colorList = new ArrayList<String>();
        obj.keySet().forEach(i->{
            Map<String, Object> tmpMap = obj.get(i);
            String color  = tmpMap.get("color").toString();
            colorList.add(color);
        });
        return colorList;
    }
    public List<String> commentList(Map<String, Map<String, Object>> obj) {
        List<String> nameList = new ArrayList<String>();
        obj.keySet().forEach(i->{
            Map<String, Object> tmpMap = obj.get(i);
            String name   = tmpMap.get("name").toString();
            String color  = tmpMap.get("color").toString();
            nameList.add(name+":"+color);
        });
        return nameList;
    }
}